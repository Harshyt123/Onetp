package com.onetap.screenshot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var actionButton: Button
    private var askedNotificationPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusText = findViewById(R.id.statusText)
        actionButton = findViewById(R.id.actionButton)
        actionButton.setOnClickListener { onActionClicked() }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun refreshUi() {
        when {
            ScreenshotService.isRunning -> {
                statusText.setText(R.string.status_running)
                actionButton.setText(R.string.stop_button)
            }
            !Settings.canDrawOverlays(this) -> {
                statusText.setText(R.string.status_need_overlay)
                actionButton.setText(R.string.grant_overlay_button)
            }
            else -> {
                statusText.setText(R.string.status_ready)
                actionButton.setText(R.string.start_button)
            }
        }
    }

    private fun onActionClicked() {
        when {
            ScreenshotService.isRunning -> {
                stopService(Intent(this, ScreenshotService::class.java))
                actionButton.postDelayed({ refreshUi() }, 400)
            }
            !Settings.canDrawOverlays(this) -> {
                Toast.makeText(this, R.string.overlay_hint, Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                !askedNotificationPermission -> {
                askedNotificationPermission = true
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
            }
            else -> requestScreenCapture()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFICATIONS) {
            // The service works even if notifications are denied, so continue either way.
            requestScreenCapture()
        }
    }

    @Suppress("DEPRECATION")
    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return

        if (resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenshotService::class.java)
                .putExtra(ScreenshotService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenshotService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(this, serviceIntent)
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_SHORT).show()
        }
    }

    private companion object {
        const val REQ_CAPTURE = 1001
        const val REQ_NOTIFICATIONS = 1002
    }
}
