package com.onetap.screenshot

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

/**
 * Foreground service that owns the MediaProjection, keeps ONE VirtualDisplay alive
 * (required on Android 14+, where a projection token can only be used once) and shows
 * a draggable floating button. Tapping the button grabs the latest frame and saves it.
 */
class ScreenshotService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var displayManager: DisplayManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestImage: Image? = null

    private var overlayView: ImageView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var overlaySize = 0

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0
    private var capturing = false

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val oldWidth = screenWidth
            val oldHeight = screenHeight
            readScreenSize()
            val mp = projection ?: return
            if (oldWidth != screenWidth || oldHeight != screenHeight) {
                attachDisplay(mp)   // rotation: resize the same VirtualDisplay
                clampOverlay()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.app_name),
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Must happen before getMediaProjection() (Android 14+ requirement).
        startForeground(
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        if (projection != null) return START_NOT_STICKY // already running

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = intent?.let { readProjectionData(it) }
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            showToast(R.string.overlay_missing)
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(resultCode, data)
            if (mp == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            projection = mp

            // A callback must be registered before createVirtualDisplay() on Android 14+.
            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    mainHandler.post { stopSelf() }
                }
            }
            projectionCallback = callback
            mp.registerCallback(callback, mainHandler)

            readScreenSize()
            attachDisplay(mp)
            displayManager.registerDisplayListener(displayListener, mainHandler)
            addOverlay()
            isRunning = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start screen capture", e)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- capture pipeline

    @Suppress("DEPRECATION")
    private fun readScreenSize() {
        val metrics = DisplayMetrics()
        displayManager.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
    }

    /** Creates the VirtualDisplay once; afterwards only resizes it and swaps the surface. */
    private fun attachDisplay(mp: MediaProjection) {
        latestImage?.close()
        latestImage = null
        val oldReader = imageReader

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ r -> onFrame(r) }, mainHandler)
        imageReader = reader

        val existing = virtualDisplay
        if (existing == null) {
            virtualDisplay = mp.createVirtualDisplay(
                "OneTapScreenshot",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )
        } else {
            existing.resize(screenWidth, screenHeight, screenDensity)
            existing.setSurface(reader.surface)
        }
        oldReader?.close()
    }

    /** Keeps the newest frame so a tap can use it even if the screen is static. */
    private fun onFrame(reader: ImageReader) {
        try {
            val image = reader.acquireLatestImage() ?: return
            latestImage?.close()
            latestImage = image
        } catch (e: IllegalStateException) {
            Log.w(TAG, "Could not acquire frame", e)
        }
    }

    private fun onButtonTapped() {
        if (capturing) return
        capturing = true
        // Hide the button so it does not appear in the screenshot, then let a fresh frame arrive.
        overlayView?.visibility = View.INVISIBLE
        mainHandler.postDelayed({ grabAndSave() }, CAPTURE_DELAY_MS)
    }

    private fun grabAndSave() {
        var bitmap: Bitmap? = null
        try {
            bitmap = imageToBitmap(latestImage)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read frame", e)
        } finally {
            overlayView?.visibility = View.VISIBLE
            capturing = false
        }
        val captured = bitmap
        if (captured == null) {
            showToast(R.string.not_ready)
            return
        }
        ioExecutor.execute { saveBitmap(captured) }
    }

    private fun imageToBitmap(image: Image?): Bitmap? {
        if (image == null) return null
        val plane = image.planes[0]
        val buffer = plane.buffer
        buffer.rewind() // the same frame may be captured more than once
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height
        val rowPadding = rowStride - pixelStride * width

        val padded = Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        if (rowPadding == 0) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val resolver = contentResolver
        val name = "Screenshot_" +
            SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Screenshots")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        var createdUri: Uri? = null
        try {
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("MediaStore insert failed")
            createdUri = uri
            val stream = resolver.openOutputStream(uri)
                ?: throw IOException("Could not open output stream")
            stream.use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                    throw IOException("PNG compression failed")
                }
            }
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            showToast(R.string.saved)
        } catch (e: Exception) {
            Log.e(TAG, "Saving screenshot failed", e)
            createdUri?.let { resolver.delete(it, null, null) }
            showToast(R.string.save_failed)
        } finally {
            bitmap.recycle()
        }
    }

    // ---------------------------------------------------------------- floating button

    @SuppressLint("ClickableViewAccessibility")
    private fun addOverlay() {
        overlaySize = dp(56)
        val size = overlaySize

        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_camera)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            contentDescription = getString(R.string.button_description)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(210, 30, 136, 229))
                setStroke(dp(2), Color.argb(200, 255, 255, 255))
            }
        }

        val params = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = screenHeight / 3
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downRawX = 0f
        var downRawY = 0f
        var dragging = false

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) {
                        params.x = (startX + dx).toInt().coerceIn(0, max(0, screenWidth - size))
                        params.y = (startY + dy).toInt().coerceIn(0, max(0, screenHeight - size))
                        windowManager.updateViewLayout(v, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) v.performClick()
                    true
                }
                else -> false
            }
        }
        view.setOnClickListener { onButtonTapped() }

        windowManager.addView(view, params)
        overlayView = view
        overlayParams = params
    }

    private fun clampOverlay() {
        val view = overlayView ?: return
        val params = overlayParams ?: return
        params.x = params.x.coerceIn(0, max(0, screenWidth - overlaySize))
        params.y = params.y.coerceIn(0, max(0, screenHeight - overlaySize))
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Overlay already removed", e)
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "Overlay already removed", e)
            }
        }
        overlayView = null
        overlayParams = null
    }

    // ---------------------------------------------------------------- helpers

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), flags
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ScreenshotService::class.java).setAction(ACTION_STOP),
            flags
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_camera)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.stop_button), stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    @Suppress("DEPRECATION")
    private fun readProjectionData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra<Intent>(EXTRA_DATA)
        }

    private fun showToast(resId: Int) {
        mainHandler.post {
            Toast.makeText(applicationContext, resId, Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        try {
            displayManager.unregisterDisplayListener(displayListener)
        } catch (e: Exception) {
            Log.w(TAG, "Display listener cleanup failed", e)
        }
        removeOverlay()
        latestImage?.close()
        latestImage = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop()
        projection = null
        ioExecutor.shutdown()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val ACTION_STOP = "com.onetap.screenshot.action.STOP"

        private const val TAG = "OneTapScreenshot"
        private const val CHANNEL_ID = "onetap_screenshot"
        private const val NOTIFICATION_ID = 1001
        private const val CAPTURE_DELAY_MS = 150L

        @Volatile
        var isRunning = false
            private set
    }
}
