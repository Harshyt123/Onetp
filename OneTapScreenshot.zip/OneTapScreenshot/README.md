# OneTap Screenshot

Floating, draggable one-tap screenshot button for Android 10+ (Kotlin + MediaProjection).
Screenshots are saved to Pictures/Screenshots.

## Build the APK (Android Studio)
1. Open Android Studio > File > Open > select the OneTapScreenshot folder.
2. Wait for Gradle sync (accept any prompt to install Android SDK Platform 34).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup, or open app/build/outputs/apk/debug/app-debug.apk.
5. Copy the APK to the phone and install it.
